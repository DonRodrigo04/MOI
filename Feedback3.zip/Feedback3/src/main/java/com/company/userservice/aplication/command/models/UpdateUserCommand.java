package com.company.userservice.aplication.command.models;
import com.company.userservice.aplication.common.Command;
/**
 * Comando para actualizar un usuario existente
 * Contiene el ID del usuario y los campos que pueden actualizarse
 * No devuelve ningún valor (void)
 */
public class UpdateUserCommand implements Command<Void> {
    private final Long userId;
    private final String email;
    private final String fullName;
    private final String role;

    public UpdateUserCommand(Long userId, String email, String fullName, String role) {
        this.userId = userId;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
    }

    public Long getUserId() {
        return userId;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getRole() {
        return role;
    }
}

