package com.company.userservice.infrastructure.persistence;

import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
import com.company.userservice.infrastructure.persistence.jpa.UserJpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Implementación del repositorio de usuarios utilizando JPA
 */
@Component
public class UserRepositoryImpl implements UserRepository {
    private final UserJpaRepository jpaRepository;

    public UserRepositoryImpl(UserJpaRepository jpaRepository) {
        this.jpaRepository = jpaRepository;
    }

    @Override
    public User save(User user) {
        return jpaRepository.save(user);
    }

    @Override
    public Optional<User> findById(Long id) {
        return jpaRepository.findById(id);
    }

    @Override
    public Optional<User> findByUsername(String username) {
        return jpaRepository.findByUsername(username);
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return jpaRepository.findByEmail(email);
    }

    @Override
    public boolean existsByUsername(String username) {
        return jpaRepository.existsByUsername(username);
    }

    @Override
    public boolean existsByEmail(String email) {
        return jpaRepository.existsByEmail(email);
    }

    @Override
    public List<User> findByFilters(String usernameFilter, String emailFilter, String roleFilter, int page, int size) {
        return jpaRepository.findByFilters(usernameFilter, emailFilter, roleFilter)
                .stream()
                .skip((long) page * size)
                .limit(size)
                .toList();
    }

    @Override
    public void delete(User user) {
        jpaRepository.delete(user);
    }

    @Override
    public long count() {
        return jpaRepository.count();
    }
}