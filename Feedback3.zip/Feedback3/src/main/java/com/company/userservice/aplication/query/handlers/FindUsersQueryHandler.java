package com.company.userservice.aplication.query.handlers;
import com.company.userservice.aplication.common.handlers.QueryHandler;
import com.company.userservice.aplication.query.models.FindUsersQuery;
import com.company.userservice.aplication.query.models.UserDto;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Manejador de la consulta FindUsersQuery
 * Implementa la lógica para buscar usuarios con criterios de filtrado
 */
public class FindUsersQueryHandler implements QueryHandler<FindUsersQuery, List<UserDto>> {
    private final UserRepository userRepository;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public FindUsersQueryHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<UserDto> handle(FindUsersQuery query) {
        // Buscar usuarios con los filtros proporcionados
        List<User> users = userRepository.findByFilters(
                query.getUsernameFilter(),
                query.getEmailFilter(),
                query.getRoleFilter(),
                query.getPage(),
                query.getSize()
        );

        // Mapear la lista de usuarios a DTOs
        return users.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private UserDto mapToDto(User user) {
        return new UserDto(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getFullName(),
                user.getRole(),
                user.isActive(),
                user.getCreatedAt().format(DATE_FORMATTER),
                user.getLastLogin() != null ? user.getLastLogin().format(DATE_FORMATTER) : null
        );
    }
}
