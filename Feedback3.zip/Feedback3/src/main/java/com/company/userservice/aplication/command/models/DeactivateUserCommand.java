package com.company.userservice.aplication.command.models;
import com.company.userservice.aplication.common.Command;
/**
 * Comando para desactivar un usuario
 * Requiere el ID del usuario y un motivo de desactivación
 * No devuelve ningún valor (void)
 */
public class DeactivateUserCommand implements Command<Void> {
    private final Long userId;
    private final String reason;

    public DeactivateUserCommand(Long userId, String reason) {
        this.userId = userId;
        this.reason = reason;
    }

    public Long getUserId() {
        return userId;
    }

    public String getReason() {
        return reason;
    }
}
