package com.company.userservice.aplication.common.handlers;

import com.company.userservice.aplication.common.Command;

/**
 * Interfaz base para todos los manejadores de comandos
 * Cada comando tiene un manejador específico que implementa la lógica de ejecución.
 *
 * @param <C> Tipo de comando
 * @param <R> Tipo de respuesta
 */
public interface CommandHandler<C extends Command<R>, R> {
    //Ejecuta el comando y devuelve el resultado
    R handle(C command);
}