package com.company.userservice.aplication.query.models;
/**
 * DTO (Data Transfer Object) para transferir datos de usuario
 * Contiene solo los datos necesarios para la visualización
 * Usado en las respuestas de las consultas
 */
public class UserDto {
    private final Long id;
    private final String username;
    private final String email;
    private final String fullName;
    private final String role;
    private final boolean active;
    private final String createdAt;
    private final String lastLogin;

    public UserDto(Long id, String username, String email, String fullName,
                   String role, boolean active, String createdAt, String lastLogin) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.active = active;
        this.createdAt = createdAt;
        this.lastLogin = lastLogin;
    }
    // Getters
    public Long getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getFullName() { return fullName; }
    public String getRole() { return role; }
    public boolean isActive() { return active; }
    public String getCreatedAt() { return createdAt; }
    public String getLastLogin() { return lastLogin; }
}
