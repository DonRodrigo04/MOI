package com.company.userservice.domain.model;

import java.time.LocalDateTime;

/**
 * Entidad de dominio que representa un usuario del sistema.
 * Contiene la lógica de negocio relacionada con usuarios.
 */
public class User {
    private Long id;
    private String username;
    private String email;
    private String password;
    private String fullName;
    private String role;
    private boolean active;
    private String deactivationReason;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    private LocalDateTime updatedAt;

    public User(String username, String email, String password, String fullName, String role) {
        // Validaciones de dominio
        validateUsername(username);
        validateEmail(email);
        validatePassword(password);
        validateRole(role);

        this.username = username;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
        this.active = true;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    protected User() {
        // Constructor necesario para JPA
    }

    public void updateProfile(String email, String fullName, String role) {
        validateEmail(email);
        validateRole(role);

        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.updatedAt = LocalDateTime.now();
    }

    public void changePassword(String newPassword) {
        validatePassword(newPassword);

        this.password = newPassword;
        this.updatedAt = LocalDateTime.now();
    }

    public void deactivate(String reason) {
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Deactivation reason cannot be empty");
        }

        this.active = false;
        this.deactivationReason = reason;
        this.updatedAt = LocalDateTime.now();
    }

    public void activate() {
        this.active = true;
        this.deactivationReason = null;
        this.updatedAt = LocalDateTime.now();
    }

    public void recordLogin() {
        this.lastLogin = LocalDateTime.now();
    }

    private void validateUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }

        if (username.length() < 3 || username.length() > 50) {
            throw new IllegalArgumentException("Username must be between 3 and 50 characters");
        }

        if (!username.matches("^[a-zA-Z0-9_.-]+$")) {
            throw new IllegalArgumentException("Username can only contain letters, numbers, dots, underscores and hyphens");
        }
    }

    private void validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email cannot be empty");
        }

        // Validación simple de formato de email
        if (!email.matches("^[^@]+@[^@]+\\.[^@]+$")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    private void validatePassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
    }

    private void validateRole(String role) {
        if (role == null || role.trim().isEmpty()) {
            throw new IllegalArgumentException("Role cannot be empty");
        }

        // En una implementación real, verificaríamos contra una lista de roles válidos
    }

    // Getters
    public Long getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getFullName() { return fullName; }
    public String getRole() { return role; }
    public boolean isActive() { return active; }
    public String getDeactivationReason() { return deactivationReason; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getLastLogin() { return lastLogin; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // Setters protegidos para JPA
    protected void setId(Long id) { this.id = id; }
    protected void setUsername(String username) { this.username = username; }
    protected void setEmail(String email) { this.email = email; }
    protected void setPassword(String password) { this.password = password; }
    protected void setFullName(String fullName) { this.fullName = fullName; }
    protected void setRole(String role) { this.role = role; }
    protected void setActive(boolean active) { this.active = active; }
    protected void setDeactivationReason(String reason) { this.deactivationReason = reason; }
    protected void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    protected void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    protected void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id != null && Objects.equals(id, user.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
