package com.company.userservice.aplication.common;
/**
 * Interfaz base para todas las consultas (operaciones de lectura)
 * Sigue el patrón Query del patrón CQRS.
 *
 * @param <R> Tipo de respuesta que devuelve la consulta
 */
public interface Query<R> {
    // Interfaz marcadora para identificar consultas
}