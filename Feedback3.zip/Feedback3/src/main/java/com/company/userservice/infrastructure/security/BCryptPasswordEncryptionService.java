package com.company.userservice.infrastructure.security;

import com.company.userservice.domain.service.PasswordEncryptionService;

/**
 * Implementación del servicio de encriptación de contraseñas utilizando BCrypt
 */
@Component
public class BCryptPasswordEncryptionService implements PasswordEncryptionService {
    private final BCryptPasswordEncoder passwordEncoder;

    public BCryptPasswordEncryptionService() {
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public String encrypt(String rawPassword) {
        return passwordEncoder.encode(rawPassword);
    }

    @Override
    public boolean matches(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }
}
