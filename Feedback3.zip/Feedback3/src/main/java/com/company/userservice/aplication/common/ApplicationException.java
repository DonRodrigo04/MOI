package com.company.userservice.aplication.common;
/**
 * Excepción base para todas las excepciones de aplicación
 * Permite diferenciar excepciones de negocio de excepciones técnicas
 */
public class ApplicationException extends RuntimeException {
  /**
   * Código de error único que identifica el tipo específico de error.
   * Permite a los manejadores de excepciones tomar decisiones basadas en este código.
   * Es final para garantizar inmutabilidad después de la creación.
   */
  private final String errorCode;
  /**
   * Constructor principal que acepta un mensaje descriptivo y un código de error.
   *
   * @param message Descripción legible del error para diagnóstico
   * @param errorCode Código que identifica el tipo de error (ej. "USER_NOT_FOUND")
   */
  public ApplicationException(String message, String errorCode) {
    super(message);
    this.errorCode = errorCode;
  }
  /**
   * Constructor secundario que también acepta una excepción causa.
   * Útil cuando esta excepción se lanza como resultado de otra excepción,
   * preservando así la stack trace original para diagnóstico.
   *
   * @param message Descripción legible del error
   * @param errorCode Código que identifica el tipo de error
   * @param cause Excepción original que provocó este error
   */
  public ApplicationException(String message, String errorCode, Throwable cause) {
    super(message, cause);
    this.errorCode = errorCode;
  }
  /**
   * Método getter para obtener el código de error.
   * Permite a los manejadores de excepciones acceder al código
   * para tomar decisiones específicas (por ejemplo, mostrar diferentes
   * mensajes al usuario o realizar acciones correctivas).
   *
   * @return El código de error asociado con esta excepción
   */
  public String getErrorCode() {
    return errorCode;
  }
}