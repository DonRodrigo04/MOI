package com.company.userservice.aplication.command.models;
import com.company.userservice.aplication.common.Command;
/**
 * Comando para cambiar la contraseña de un usuario
 * Requiere el ID del usuario, la contraseña actual y la nueva
 * No devuelve ningún valor (void)
 */
public class ChangePasswordCommand implements Command<Void> {
    private final Long userId;
    private final String currentPassword;
    private final String newPassword;

    public ChangePasswordCommand(Long userId, String currentPassword, String newPassword) {
        this.userId = userId;
        this.currentPassword = currentPassword;
        this.newPassword = newPassword;
    }

    public Long getUserId() {
        return userId;
    }

    public String getCurrentPassword() {
        return currentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }
}