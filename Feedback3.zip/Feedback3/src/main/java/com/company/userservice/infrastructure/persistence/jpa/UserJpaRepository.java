package com.company.userservice.infrastructure.persistence.jpa;

import com.company.userservice.domain.model.User;

import java.util.Optional;

/**
 * Repositorio JPA para acceso a datos de usuarios
 */
@Repository
public interface UserJpaRepository extends JpaRepository<User, Long> {

    //Busca un usuario por su nombre de usuario
    Optional<User> findByUsername(String username);

    //Busca un usuario por su email
    Optional<User> findByEmail(String email);

    // Verifica si existe un usuario con el nombre de usuario especificado
    boolean existsByUsername(String username);

    //Verifica si existe un usuario con el email especificado
    boolean existsByEmail(String email);

    //Búsqueda personalizada por filtros
    @Query("SELECT u FROM User u WHERE " +
            "(:username IS NULL OR u.username LIKE %:username%) AND " +
            "(:email IS NULL OR u.email LIKE %:email%) AND " +
            "(:role IS NULL OR u.role = :role)")
    java.util.List<User> findByFilters(
            @Param("username") String username,
            @Param("email") String email,
            @Param("role") String role);
}