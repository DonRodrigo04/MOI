package com.company.userservice.aplication.query.models;
import com.company.userservice.aplication.common.Query;
import java.util.List;
/**
 * Consulta para buscar usuarios con criterios de filtrado y paginación
 * Devuelve una lista de UserDto que cumplen los criterios
 */
public class FindUsersQuery implements Query<List<UserDto>> {
    private final String usernameFilter;
    private final String emailFilter;
    private final String roleFilter;
    private final int page;
    private final int size;

    public FindUsersQuery(String usernameFilter, String emailFilter, String roleFilter, int page, int size) {
        this.usernameFilter = usernameFilter;
        this.emailFilter = emailFilter;
        this.roleFilter = roleFilter;
        this.page = page;
        this.size = size;
    }

    public String getUsernameFilter() {
        return usernameFilter;
    }

    public String getEmailFilter() {
        return emailFilter;
    }

    public String getRoleFilter() {
        return roleFilter;
    }

    public int getPage() {
        return page;
    }

    public int getSize() {
        return size;
    }
}