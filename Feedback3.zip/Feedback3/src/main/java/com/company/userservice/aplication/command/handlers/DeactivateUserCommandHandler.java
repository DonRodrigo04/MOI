package com.company.userservice.aplication.command.handlers;
import com.company.userservice.aplication.command.models.DeactivateUserCommand;
import com.company.userservice.aplication.common.ApplicationException;
import com.company.userservice.aplication.common.handlers.CommandHandler;
import com.company.userservice.aplication.events.DomainEventPublisher;
import com.company.userservice.aplication.events.UserDeactivatedEvent;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
/**
 * Manejador del comando DeactivateUserCommand
 * Implementa la lógica para desactivar un usuario
 */
public class DeactivateUserCommandHandler implements CommandHandler<DeactivateUserCommand, Void> {
    private final UserRepository userRepository;
    private final DomainEventPublisher eventPublisher;

    public DeactivateUserCommandHandler(
            UserRepository userRepository,
            DomainEventPublisher eventPublisher) {
        this.userRepository = userRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public Void handle(DeactivateUserCommand command) {
        // Buscar el usuario
        User user = userRepository.findById(command.getUserId())
                .orElseThrow(() -> new ApplicationException("User not found", "USER_NOT_FOUND"));
        // Verificar que el usuario esté activo
        if (!user.isActive()) {
            throw new ApplicationException("User is already inactive", "USER_ALREADY_INACTIVE");
        }
        // Desactivar el usuario
        user.deactivate(command.getReason());
        // Persistir los cambios
        userRepository.save(user);
        // Publicar evento de dominio
        eventPublisher.publish(new UserDeactivatedEvent(
                user.getId(),
                command.getReason()
        ));

        return null; // Comando sin retorno (void)
    }
}
