package com.company.userservice.aplication.query.models;
import com.company.userservice.aplication.common.Query;
/**
 * Consulta para obtener un usuario por su ID
 * Devuelve un UserDto con los datos del usuario
 */
public class GetUserByIdQuery implements Query<UserDto> {
    private final Long userId;

    public GetUserByIdQuery(Long userId) {
        this.userId = userId;
    }

    public Long getUserId() {
        return userId;
    }
}