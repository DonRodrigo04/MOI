package com.company.userservice.domain.service;
/**
 * Servicio para encriptar y verificar contraseñas
 * Define el contrato que debe implementar la capa de infraestructura
 */
public interface PasswordEncryptionService {

    String encrypt(String rawPassword);

    boolean matches(String rawPassword, String encodedPassword);
}
