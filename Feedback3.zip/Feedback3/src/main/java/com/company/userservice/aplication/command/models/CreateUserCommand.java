package com.company.userservice.aplication.command.models;
import com.company.userservice.aplication.common.Command;
/**
 * Comando para crear un nuevo usuario
 * Contiene todos los datos necesarios para la creación
 * Devuelve el ID del usuario creado
 */
public class CreateUserCommand implements Command<Long> {
    private final String username;
    private final String email;
    private final String password;
    private final String fullName;
    private final String role;

    public CreateUserCommand(String username, String email, String password, String fullName, String role) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getFullName() {
        return fullName;
    }

    public String getRole() {
        return role;
    }
}
