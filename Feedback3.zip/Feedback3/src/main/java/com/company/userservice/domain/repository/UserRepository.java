package com.company.userservice.domain.repository;

import com.company.userservice.domain.model.User;

import java.util.List;
import java.util.Optional;

/**
 * Repositorio para operaciones con usuarios
 * Define el contrato que debe implementar la capa de infraestructura
 */
public interface UserRepository {

    User save(User user);

    Optional<User> findById(Long id);

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    /**
     * Busca usuarios con filtros específicos
     *
     * @param usernameFilter Filtro de nombre de usuario (puede ser null)
     * @param emailFilter Filtro de email (puede ser null)
     * @param roleFilter Filtro de rol (puede ser null)
     * @param page Número de página (base 0)
     * @param size Tamaño de página
     * @return Lista de usuarios que cumplen los criterios
     */
    List<User> findByFilters(String usernameFilter, String emailFilter, String roleFilter, int page, int size);

    void delete(User user);

    long count();
}
