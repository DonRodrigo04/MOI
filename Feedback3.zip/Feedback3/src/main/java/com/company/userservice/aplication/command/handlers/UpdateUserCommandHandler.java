package com.company.userservice.aplication.command.handlers;
import com.company.userservice.aplication.command.models.UpdateUserCommand;
import com.company.userservice.aplication.common.ApplicationException;
import com.company.userservice.aplication.common.handlers.CommandHandler;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
/**
 * Manejador del comando UpdateUserCommand
 * Implementa la lógica para actualizar un usuario existente
 */
public class UpdateUserCommandHandler implements CommandHandler<UpdateUserCommand, Void> {
    private final UserRepository userRepository;

    public UpdateUserCommandHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Void handle(UpdateUserCommand command) {
        // Buscar el usuario
        User user = userRepository.findById(command.getUserId())
                .orElseThrow(() -> new ApplicationException("User not found", "USER_NOT_FOUND"));
        // Validar si el email ya está en uso por otro usuario
        if (!user.getEmail().equals(command.getEmail()) &&
                userRepository.existsByEmail(command.getEmail())) {
            throw new ApplicationException("Email already in use", "EMAIL_ALREADY_EXISTS");
        }
        // Actualizar los datos del usuario
        user.updateProfile(
                command.getEmail(),
                command.getFullName(),
                command.getRole()
        );
        // Persistir los cambios
        userRepository.save(user);

        return null; // Comando sin retorno (void)
    }
}
