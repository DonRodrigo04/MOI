package com.company.userservice.aplication.common.handlers;
import com.company.userservice.aplication.common.Query;
/**
 * Interfaz base para todos los manejadores de consultas
 * Cada consulta tiene un manejador específico que implementa la lógica de ejecución.
 *
 * @param <Q> Tipo de consulta
 * @param <R> Tipo de respuesta
 */
public interface QueryHandler<Q extends Query<R>, R> {
    //Ejecuta la consulta y devuelve el resultado
    R handle(Q query);
}
