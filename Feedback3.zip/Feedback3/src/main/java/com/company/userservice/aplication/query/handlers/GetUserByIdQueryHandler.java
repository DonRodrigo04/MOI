package com.company.userservice.aplication.query.handlers;
import com.company.userservice.aplication.common.ApplicationException;
import com.company.userservice.aplication.common.handlers.QueryHandler;
import com.company.userservice.aplication.query.models.GetUserByIdQuery;
import com.company.userservice.aplication.query.models.UserDto;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
import java.time.format.DateTimeFormatter;
/**
 * Manejador de la consulta GetUserByIdQuery
 * Implementa la lógica para obtener un usuario por su ID
 */
public class GetUserByIdQueryHandler implements QueryHandler<GetUserByIdQuery, UserDto> {
    private final UserRepository userRepository;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public GetUserByIdQueryHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDto handle(GetUserByIdQuery query) {
        // Buscar el usuario
        User user = userRepository.findById(query.getUserId())
                .orElseThrow(() -> new ApplicationException("User not found", "USER_NOT_FOUND"));

        // Mapear el usuario a DTO
        return mapToDto(user);
    }

    private UserDto mapToDto(User user) {
        return new UserDto(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getFullName(),
                user.getRole(),
                user.isActive(),
                user.getCreatedAt().format(DATE_FORMATTER),
                user.getLastLogin() != null ? user.getLastLogin().format(DATE_FORMATTER) : null
        );
    }
}
