package com.company.userservice.infrastructure.rest;

import com.company.userservice.aplication.common.ApplicationException;

/**
 * Controlador REST para las operaciones relacionadas con usuarios
 */
@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserServiceFacade userServiceFacade;

    public UserController(UserServiceFacade userServiceFacade) {
        this.userServiceFacade = userServiceFacade;
    }

    /**
     * Crea un nuevo usuario
     */
    @PostMapping
    public ResponseEntity<Long> createUser(@Valid @RequestBody CreateUserRequest request) {
        Long userId = userServiceFacade.createUser(
                request.getUsername(),
                request.getEmail(),
                request.getPassword(),
                request.getFullName(),
                request.getRole()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(userId);
    }

    /**
     * Actualiza un usuario existente
     */
    @PutMapping("/{userId}")
    public ResponseEntity<Void> updateUser(
            @PathVariable Long userId,
            @Valid @RequestBody UpdateUserRequest request) {
        userServiceFacade.updateUser(
                userId,
                request.getEmail(),
                request.getFullName(),
                request.getRole()
        );
        return ResponseEntity.ok().build();
    }

    /**
     * Cambia la contraseña de un usuario
     */
    @PostMapping("/{userId}/change-password")
    public ResponseEntity<Void> changePassword(
            @PathVariable Long userId,
            @RequestParam String currentPassword,
            @RequestParam String newPassword) {
        userServiceFacade.changePassword(userId, currentPassword, newPassword);
        return ResponseEntity.ok().build();
    }

    /**
     * Desactiva un usuario
     */
    @PostMapping("/{userId}/deactivate")
    public ResponseEntity<Void> deactivateUser(
            @PathVariable Long userId,
            @RequestParam String reason) {
        userServiceFacade.deactivateUser(userId, reason);
        return ResponseEntity.ok().build();
    }

    /**
     * Obtiene un usuario por su ID
     */
    @GetMapping("/{userId}")
    public ResponseEntity<UserDto> getUserById(@PathVariable Long userId) {
        UserDto user = userServiceFacade.getUserById(userId);
        return ResponseEntity.ok(user);
    }

    /**
     * Busca usuarios según criterios
     */
    @GetMapping
    public ResponseEntity<List<UserDto>> findUsers(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String role,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        List<UserDto> users = userServiceFacade.findUsers(username, email, role, page, size);
        return ResponseEntity.ok(users);
    }

    /**
     * Verifica si existe un usuario con el nombre especificado
     */
    @GetMapping("/check-username")
    public ResponseEntity<Boolean> checkUsernameExists(@RequestParam String username) {
        boolean exists = userServiceFacade.checkUsernameExists(username);
        return ResponseEntity.ok(exists);
    }

    /**
     * Manejador global de excepciones de aplicación
     */
    @ExceptionHandler(ApplicationException.class)
    public ResponseEntity<ErrorResponse> handleApplicationException(ApplicationException ex) {
        ErrorResponse error = new ErrorResponse(ex.getErrorCode(), ex.getMessage());

        HttpStatus status;
        switch (ex.getErrorCode()) {
            case "USER_NOT_FOUND":
                status = HttpStatus.NOT_FOUND;
                break;
            case "USER_ALREADY_EXISTS":
            case "EMAIL_ALREADY_EXISTS":
                status = HttpStatus.CONFLICT;
                break;
            case "INVALID_PASSWORD":
                status = HttpStatus.BAD_REQUEST;
                break;
            default:
                status = HttpStatus.INTERNAL_SERVER_ERROR;
        }

        return new ResponseEntity<>(error, status);
    }
}
