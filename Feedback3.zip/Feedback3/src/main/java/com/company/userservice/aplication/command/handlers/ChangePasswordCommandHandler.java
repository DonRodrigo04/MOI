package com.company.userservice.aplication.command.handlers;
import com.company.userservice.aplication.command.models.ChangePasswordCommand;
import com.company.userservice.aplication.common.ApplicationException;
import com.company.userservice.aplication.common.handlers.CommandHandler;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
import com.company.userservice.domain.service.PasswordEncryptionService;
/**
 * Manejador del comando ChangePasswordCommand
 * Implementa la lógica para cambiar la contraseña de un usuario
 */
public class ChangePasswordCommandHandler implements CommandHandler<ChangePasswordCommand, Void> {
    private final UserRepository userRepository;
    private final PasswordEncryptionService passwordEncryptionService;

    public ChangePasswordCommandHandler(
            UserRepository userRepository,
            PasswordEncryptionService passwordEncryptionService) {
        this.userRepository = userRepository;
        this.passwordEncryptionService = passwordEncryptionService;
    }

    @Override
    public Void handle(ChangePasswordCommand command) {
        // Buscar el usuario
        User user = userRepository.findById(command.getUserId())
                .orElseThrow(() -> new ApplicationException("User not found", "USER_NOT_FOUND"));
        // Verificar que la contraseña actual sea correcta
        if (!passwordEncryptionService.matches(command.getCurrentPassword(), user.getPassword())) {
            throw new ApplicationException("Current password is incorrect", "INVALID_PASSWORD");
        }
        // Encriptar la nueva contraseña
        String newEncryptedPassword = passwordEncryptionService.encrypt(command.getNewPassword());
        // Actualizar la contraseña
        user.changePassword(newEncryptedPassword);
        // Persistir los cambios
        userRepository.save(user);

        return null; // Comando sin retorno (void)
    }
}