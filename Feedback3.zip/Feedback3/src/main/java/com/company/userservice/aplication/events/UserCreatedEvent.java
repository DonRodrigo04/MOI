package com.company.userservice.aplication.events;
/**
 * Evento que se dispara cuando se crea un nuevo usuario
 */
public class UserCreatedEvent extends DomainEvent {
    private final Long userId;
    private final String username;
    private final String email;
    private final String role;

    public UserCreatedEvent(Long userId, String username, String email, String role) {
        super();
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.role = role;
    }

    public Long getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    @Override
    public String getEventType() {
        return "USER_CREATED";
    }
}