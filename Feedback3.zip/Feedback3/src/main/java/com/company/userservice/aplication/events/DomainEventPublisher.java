package com.company.userservice.aplication.events;
/**
 * Publicador de eventos de dominio
 * Permite a otros componentes suscribirse a eventos específicos
 */
public interface DomainEventPublisher {
    /**
     * Publica un evento para que sea procesado por los suscriptores
     *
     * @param event El evento a publicar
     */
    void publish(DomainEvent event);
}
