package com.company.userservice.aplication.command.handlers;
import com.company.userservice.aplication.command.models.CreateUserCommand;
import com.company.userservice.aplication.common.ApplicationException;
import com.company.userservice.aplication.common.handlers.CommandHandler;
import com.company.userservice.aplication.events.DomainEventPublisher;
import com.company.userservice.aplication.events.UserCreatedEvent;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
import com.company.userservice.domain.service.PasswordEncryptionService;
/**
 * Manejador del comando CreateUserCommand
 * Implementa la lógica para crear un nuevo usuario
 */
public class CreateUserCommandHandler implements CommandHandler<CreateUserCommand, Long> {
    private final UserRepository userRepository;
    private final PasswordEncryptionService passwordEncryptionService;
    private final DomainEventPublisher eventPublisher;

    public CreateUserCommandHandler(
            UserRepository userRepository,
            PasswordEncryptionService passwordEncryptionService,
            DomainEventPublisher eventPublisher) {
        this.userRepository = userRepository;
        this.passwordEncryptionService = passwordEncryptionService;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public Long handle(CreateUserCommand command) {
        // Validar si el usuario ya existe
        if (userRepository.existsByUsername(command.getUsername())) {
            throw new ApplicationException("Username already exists", "USER_ALREADY_EXISTS");
        }

        if (userRepository.existsByEmail(command.getEmail())) {
            throw new ApplicationException("Email already exists", "EMAIL_ALREADY_EXISTS");
        }
        // Encriptar la contraseña
        String encryptedPassword = passwordEncryptionService.encrypt(command.getPassword());
        // Crear la entidad de dominio
        User user = new User(
                command.getUsername(),
                command.getEmail(),
                encryptedPassword,
                command.getFullName(),
                command.getRole()
        );
        // Persistir el usuario
        User savedUser = userRepository.save(user);
        // Publicar evento de dominio
        eventPublisher.publish(new UserCreatedEvent(
                savedUser.getId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getRole()
        ));
        // Devolver el ID del usuario creado
        return savedUser.getId();
    }
}