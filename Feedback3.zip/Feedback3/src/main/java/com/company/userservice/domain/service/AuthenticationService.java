package com.company.userservice.domain.service;
import com.company.userservice.domain.model.AuthenticationResult;
import com.company.userservice.domain.model.User;
import com.company.userservice.domain.repository.UserRepository;
/**
 * Servicio de dominio para la autenticación de usuarios
 */
public class AuthenticationService {
    private final UserRepository userRepository;
    private final PasswordEncryptionService passwordEncryptionService;

    public AuthenticationService(
            UserRepository userRepository,
            PasswordEncryptionService passwordEncryptionService) {
        this.userRepository = userRepository;
        this.passwordEncryptionService = passwordEncryptionService;
    }

    public AuthenticationResult authenticate(String username, String password) {
        // Buscar el usuario por nombre de usuario
        return userRepository.findByUsername(username)
                .map(user -> authenticateUser(user, password))
                .orElse(AuthenticationResult.failure("Invalid username or password"));
    }

    private AuthenticationResult authenticateUser(User user, String password) {
        // Verificar si el usuario está activo
        if (!user.isActive()) {
            return AuthenticationResult.failure("User account is disabled");
        }

        // Verificar la contraseña
        if (!passwordEncryptionService.matches(password, user.getPassword())) {
            return AuthenticationResult.failure("Invalid username or password");
        }

        // Registrar el inicio de sesión
        user.recordLogin();
        userRepository.save(user);

        return AuthenticationResult.success(user);
    }
}
