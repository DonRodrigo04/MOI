package com.company.userservice.aplication.query.models;
import com.company.userservice.aplication.common.Query;
/**
 * Consulta para verificar si existe un usuario con un nombre de usuario específico
 * Útil para validaciones antes de crear usuarios
 */
public class CheckUsernameExistsQuery implements Query<Boolean> {
    private final String username;

    public CheckUsernameExistsQuery(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
