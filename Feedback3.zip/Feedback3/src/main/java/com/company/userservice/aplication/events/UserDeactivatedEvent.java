package com.company.userservice.aplication.events;
/**
 * Evento que se dispara cuando se desactiva un usuario
 */
public class UserDeactivatedEvent extends DomainEvent {
    private final Long userId;
    private final String reason;

    public UserDeactivatedEvent(Long userId, String reason) {
        super();
        this.userId = userId;
        this.reason = reason;
    }

    public Long getUserId() {
        return userId;
    }

    public String getReason() {
        return reason;
    }

    @Override
    public String getEventType() {
        return "USER_DEACTIVATED";
    }
}
