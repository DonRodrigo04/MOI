package com.company.userservice.aplication.query.handlers;
import com.company.userservice.aplication.common.handlers.QueryHandler;
import com.company.userservice.aplication.query.models.CheckUsernameExistsQuery;
import com.company.userservice.domain.repository.UserRepository;
/**
 * Manejador de la consulta CheckUsernameExistsQuery
 * Implementa la lógica para verificar si existe un usuario con un nombre específico
 */
public class CheckUsernameExistsQueryHandler implements QueryHandler<CheckUsernameExistsQuery, Boolean> {
    private final UserRepository userRepository;

    public CheckUsernameExistsQueryHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Boolean handle(CheckUsernameExistsQuery query) {
        // Verificar si existe un usuario con el nombre de usuario proporcionado
        return userRepository.existsByUsername(query.getUsername());
    }
}
