package com.company.userservice.domain.model;
/**
 * Objeto de valor que representa un resultado de autenticación
 */
public class AuthenticationResult {
    private final boolean success;
    private final User user;
    private final String errorMessage;

    public static AuthenticationResult success(User user) {
        return new AuthenticationResult(true, user, null);
    }

    public static AuthenticationResult failure(String errorMessage) {
        return new AuthenticationResult(false, null, errorMessage);
    }

    private AuthenticationResult(boolean success, User user, String errorMessage) {
        this.success = success;
        this.user = user;
        this.errorMessage = errorMessage;
    }

    public boolean isSuccess() {
        return success;
    }

    public User getUser() {
        if (!success) {
            throw new IllegalStateException("Cannot get user from failed authentication");
        }
        return user;
    }

    public String getErrorMessage() {
        if (success) {
            throw new IllegalStateException("Cannot get error message from successful authentication");
        }
        return errorMessage;
    }
}
